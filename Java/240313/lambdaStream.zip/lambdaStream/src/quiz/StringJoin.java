package quiz;

public class StringJoin {
	public static void main(String[] args) {
		String[] words = {"elice", "racer", "is", "awesome"};
		String message = String.join(" ", words);
		System.out.println(message);
	}
}
