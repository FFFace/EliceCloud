package ocp;

// 할인 정책 인터페이스
interface DiscountPolicy {
	double applyDiscount(double price);
}
