package dip;

public interface AudioPlayer {
	void play(String songName);
}
