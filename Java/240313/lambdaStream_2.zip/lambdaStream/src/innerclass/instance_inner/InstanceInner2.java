package innerclass.instance_inner;

public class InstanceInner2 {
}
