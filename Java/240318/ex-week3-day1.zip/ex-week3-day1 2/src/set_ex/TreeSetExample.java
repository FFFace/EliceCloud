package set_ex;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetExample {
	public static void main(String[] args) {
		Set<Double> scoreSet = new TreeSet<>();
		scoreSet.add(9.5);
		scoreSet.add(7.3);
		scoreSet.add(5.8);
		scoreSet.add(9.5); // 중복된 요소는 추가되지 않음

		for (Double score : scoreSet) {
			System.out.println(score);
		}
	}
}

