package exception_ex.custom.network;

class NetworkConnectionException extends Exception {
	public NetworkConnectionException(String message) {
		super(message);
	}
}

