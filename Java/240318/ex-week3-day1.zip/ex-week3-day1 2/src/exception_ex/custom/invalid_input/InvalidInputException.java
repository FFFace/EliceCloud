package exception_ex.custom.invalid_input;

class InvalidInputException extends Exception {
	public InvalidInputException(String message) {
		super(message);
	}
}

