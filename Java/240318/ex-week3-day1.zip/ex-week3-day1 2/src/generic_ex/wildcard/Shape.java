package generic_ex.wildcard;

import java.util.Arrays;
import java.util.List;

// 기본 도형 클래스
abstract class Shape {
	public abstract double area();
}

